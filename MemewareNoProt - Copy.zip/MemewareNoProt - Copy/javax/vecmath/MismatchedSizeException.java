
package javax.vecmath;

public class MismatchedSizeException
        extends RuntimeException {
    public MismatchedSizeException() {
    }

    public MismatchedSizeException(String str) {
        super(str);
    }
}

