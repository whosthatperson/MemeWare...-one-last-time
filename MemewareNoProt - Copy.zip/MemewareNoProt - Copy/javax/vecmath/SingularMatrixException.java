
package javax.vecmath;

public class SingularMatrixException
        extends RuntimeException {
    public SingularMatrixException() {
    }

    public SingularMatrixException(String str) {
        super(str);
    }
}

