
package me.memewaredevs.altmanager;

public class Alts {
}

