
package me.memewaredevs.altmanager;

public class Info {
}

