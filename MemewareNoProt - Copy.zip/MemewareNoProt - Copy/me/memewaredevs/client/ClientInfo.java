package me.memewaredevs.client;

public class ClientInfo {
    public static String build_type = "public";
}