package me.memewaredevs.client.module.combat.aura;

public class SwitchAura {
}
