package me.memewaredevs.client.module.render;

import me.memewaredevs.client.module.Module;

public class NoHurtCam extends Module {

    public NoHurtCam() {
        super("NoHurtCam", 0, Category.RENDER);
    }

}
