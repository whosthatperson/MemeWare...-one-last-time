package me.memewaredevs.client.util;

import java.util.UUID;

public class CubeUtil {
    public static final UUID CUBECRAFT_UUID = UUID.fromString("9b450781-162f-4c1d-8d1f-af2aab7e526e");
}
