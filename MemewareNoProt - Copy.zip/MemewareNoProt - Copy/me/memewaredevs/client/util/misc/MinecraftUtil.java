
package me.memewaredevs.client.util.misc;

import net.minecraft.client.Minecraft;

public interface MinecraftUtil {
    Minecraft mc = Minecraft.getMinecraft();
}
