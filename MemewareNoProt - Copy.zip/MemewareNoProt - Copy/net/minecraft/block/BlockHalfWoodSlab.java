package net.minecraft.block;

public class BlockHalfWoodSlab extends BlockWoodSlab {
    private static final String __OBFID = "CL_00002107";

    public boolean isDouble() {
        return false;
    }
}
